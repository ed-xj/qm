(function() {
var toc =  [ { "type" : "book", "name" : "Automatic Input-state Checking", "key" : "toc39" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();