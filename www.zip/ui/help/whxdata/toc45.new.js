(function() {
var toc =  [ { "type" : "book", "name" : "Gripprt Manual - API", "key" : "toc46" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();