(function() {
var toc =  [ { "type" : "item", "name" : "Motion Command Arguments", "url" : "Appendix_C/Scara_Robot_API/Appendix_A/Motion_Command_Arguments.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();