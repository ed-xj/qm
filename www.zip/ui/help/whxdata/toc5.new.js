(function() {
var toc =  [ { "type" : "item", "name" : "Automatic Mode", "url" : "System_Software/Automatic_Mode.htm" }, { "type" : "item", "name" : "Semi Automatic Mode", "url" : "System_Software/Semi_Automatic_Mode.htm" }, { "type" : "item", "name" : "Manual Mode", "url" : "System_Software/Introduction.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();