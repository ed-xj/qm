(function() {
var toc =  [ { "type" : "book", "name" : "Scara Robot API", "key" : "toc35" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();