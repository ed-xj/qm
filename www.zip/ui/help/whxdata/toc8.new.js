(function() {
var toc =  [ { "type" : "book", "name" : "Scra Robot Manual", "key" : "toc9" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();