(function() {
var toc =  [ { "type" : "item", "name" : "Equipment Hazards", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Safety/Equipment_Harzards/Equipment_Hazards.htm" }, { "type" : "item", "name" : "Physical Installation Safety", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Safety/Equipment_Harzards/Physical_Installation_Safety.htm" }, { "type" : "item", "name" : "Manual Operation Safety", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Safety/Equipment_Harzards/Manual_Operation_Safety.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();