(function() {
var toc =  [ { "type" : "item", "name" : "API Quick Reference", "url" : "Appendix_C/Scara_Robot_API/API_Quick_Reference.htm" }, { "type" : "book", "name" : "API Command Reference", "key" : "toc36" }, { "type" : "book", "name" : "Appendix A", "key" : "toc37" }, { "type" : "book", "name" : "Appendix B", "key" : "toc38" }, { "type" : "book", "name" : "Appendix C", "key" : "toc40" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();