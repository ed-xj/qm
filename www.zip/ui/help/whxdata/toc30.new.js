(function() {
var toc =  [ { "type" : "book", "name" : "Station Teaching Strategies", "key" : "toc31" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();