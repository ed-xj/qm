(function() {
var toc =  [ { "type" : "item", "name" : "General Description", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Description_of_System_Components/Controller_Unit/General_Description.htm" }, { "type" : "item", "name" : "Controller Mounting", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Description_of_System_Components/Controller_Unit/Controller_Mounting.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();