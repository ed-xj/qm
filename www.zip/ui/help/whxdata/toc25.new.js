(function() {
var toc =  [ { "type" : "book", "name" : "Troubleshooting", "key" : "toc26" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();