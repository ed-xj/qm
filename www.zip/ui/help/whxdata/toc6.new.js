(function() {
var toc =  [ { "type" : "item", "name" : "Subcomponent Manuals", "url" : "Subcomponent_Manuals/Subcomponent_Manuals.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();