(function() {
var toc =  [ { "type" : "book", "name" : "Jog Modes and Reference Frames", "key" : "toc29" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();