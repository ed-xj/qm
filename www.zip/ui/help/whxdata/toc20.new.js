(function() {
var toc =  [ { "type" : "item", "name" : "Mastering The Robot", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Mastering_The_Robot/Mastering_The_Robot.htm" }, { "type" : "item", "name" : "Mastering The IR-820", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Mastering_The_Robot/Mastering_The_IR-820.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();