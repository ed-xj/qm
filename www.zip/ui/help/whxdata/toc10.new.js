(function() {
var toc =  [ { "type" : "item", "name" : "General Description", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Introduction/General_Description.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();