(function() {
var toc =  [ { "type" : "item", "name" : "Teaching Stations", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Teaching_Stations/Teaching_Stations.htm" }, { "type" : "item", "name" : "Basic Concepts", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Teaching_Stations/Basic_Concepts.htm" }, { "type" : "item", "name" : "Prerequisites", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Teaching_Stations/Prerequisites.htm" }, { "type" : "book", "name" : "Teaching Stations", "key" : "toc24" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();