(function() {
var toc =  [ { "type" : "item", "name" : "User I/O Interface", "url" : "Appendix_B/Scra_Robot_Manual_and_API/User_IO_Interface/User_I_O_Interface.htm" }, { "type" : "item", "name" : "User I/O Connector", "url" : "Appendix_B/Scra_Robot_Manual_and_API/User_IO_Interface/User_I_O_Connector.htm" }, { "type" : "item", "name" : "E-stop Circuit", "url" : "Appendix_B/Scra_Robot_Manual_and_API/User_IO_Interface/E-stop_Circuit.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();