(function() {
var toc =  [ { "type" : "item", "name" : "Description", "url" : "Appendix_C/Scara_Robot_API/Appendix_B/Automatic_Input-state_Checking/Description.htm" }, { "type" : "item", "name" : "Affected Commands", "url" : "Appendix_C/Scara_Robot_API/Appendix_B/Automatic_Input-state_Checking/Affected_Commands.htm" }, { "type" : "item", "name" : "Notes", "url" : "Appendix_C/Scara_Robot_API/Appendix_B/Automatic_Input-state_Checking/Notes.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();