(function() {
var toc =  [ { "type" : "item", "name" : "Flipper Errors", "url" : "Appendix_C/Scara_Robot_API/Appendix_C/Subsystem_Error_Messages/Flipper_Errors.htm" }, { "type" : "item", "name" : "Pre-Aligner Errors", "url" : "Appendix_C/Scara_Robot_API/Appendix_C/Subsystem_Error_Messages/Pre-Aligner_Errors.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();