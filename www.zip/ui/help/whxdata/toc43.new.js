(function() {
var toc =  [ { "type" : "book", "name" : "Aligner Manual - API", "key" : "toc44" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();