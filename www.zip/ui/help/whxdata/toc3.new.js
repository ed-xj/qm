(function() {
var toc =  [ { "type" : "item", "name" : "Equipment Hazards", "url" : "Safety/Equipment_Hazards/Equipment_Hazards.htm" }, { "type" : "item", "name" : "Physical Installation Safety", "url" : "Safety/Equipment_Hazards/Physical_Installation_Safety.htm" }, { "type" : "item", "name" : "Manual Operation Safety", "url" : "Safety/Equipment_Hazards/Manual_Opertion_Safety.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();