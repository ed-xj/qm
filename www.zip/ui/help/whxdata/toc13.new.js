(function() {
var toc =  [ { "type" : "item", "name" : "Description of System Components", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Description_of_System_Components/Description_of_System_Components.htm" }, { "type" : "book", "name" : "Robot Mechanical Unit (RMU)", "key" : "toc14" }, { "type" : "book", "name" : "Controller Unit", "key" : "toc15" }, { "type" : "item", "name" : "Teach pendant", "url" : "Appendix_B/Scra_Robot_Manual_and_API/Description_of_System_Components/Teach_pendant.htm" } ];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();